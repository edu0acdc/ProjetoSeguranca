
cd client
java -jar client.jar SeiTchiz 127.0.0.1:12345 admin
read -s -n 1 -p "Press any key to continue . . ."
echo ""