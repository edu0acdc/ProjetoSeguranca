
cd server
java -jar server.jar SeiTchiz 12345
read -s -n 1 -p "Press any key to continue . . ."
echo ""